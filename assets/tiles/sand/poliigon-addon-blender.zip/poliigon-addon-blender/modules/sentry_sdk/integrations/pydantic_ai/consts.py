SPAN_ORIGIN = "auto.ai.pydantic_ai"
